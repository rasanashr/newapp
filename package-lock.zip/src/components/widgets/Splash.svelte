<script>
export let Splash = '/splash.png';
</script>

<div class="text-center text-2xl font-bold text-red-600 font-extra">
 <img src={Splash} alt="پایگاه خبری رسا نشر" class="w-[50%] mx-auto  select-none" draggable="false" />
    <p>پایگاه خبری تحلیلی رسا نشر </p>   
</div>
