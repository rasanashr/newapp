import{t as l,h as S,a as r}from"../chunks/CrqCNo7s.js";import{i as q}from"../chunks/C-zKQLXa.js";import{p as z,e as C,$ as F,b as m,c as a,r as t,n as P,t as R,F as T,g}from"../chunks/B6FlMjrQ.js";import{s as x}from"../chunks/iFHsnjK9.js";import{p as A,i as B}from"../chunks/CvhO7qhS.js";import{e as D,s as E,i as G}from"../chunks/BsRF2vc2.js";import{s as H}from"../chunks/B-yy7loJ.js";const ee=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));var I=l('<div class="text-center py-8 svelte-nfclae"><div class="loading loading-spinner loading-lg svelte-nfclae"></div></div>'),J=l('<a class="transform transition-all duration-300 hover:scale-105 group svelte-nfclae"><div><div class="svelte-nfclae"><span class="text-xl font-bold svelte-nfclae"> </span> <span class="text-sm opacity-75 svelte-nfclae"> </span></div> <span class="text-3xl opacity-50 group-hover:opacity-75 transition-opacity duration-300 svelte-nfclae">#</span></div></a>'),K=l('<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 svelte-nfclae"></div>'),L=l('<main class="container mx-auto px-4 py-8 svelte-nfclae"><h1 class="text-2xl font-bold text-black dark:text-white text-center mb-12 svelte-nfclae">دسته بندی مطالب منتشر شده در رسانه روز</h1> <!></main>');function te(u,d){z(d,!1);let p=A(d,"data",8)().categories;const f=["bg-yellow-200 text-yellow-800 hover:bg-yellow-300","bg-red-500 text-white hover:bg-red-600","bg-blue-300 text-blue-800 hover:bg-blue-400","bg-indigo-500 text-white hover:bg-indigo-600","bg-green-300 text-green-800 hover:bg-green-400","bg-pink-200 text-pink-800 hover:bg-pink-300","bg-sky-500 text-white hover:bg-indigo-600","bg-fuchsia-400 text-green-800 hover:bg-green-400","bg-orange-400 text-pink-800 hover:bg-pink-300"];function _(){return f[Math.floor(Math.random()*f.length)]}q();var n=L();S(e=>{F.title="رسانه روز - دسته بندی مطالب منتشر شده در رسانه روز"});var y=m(a(n),2);{var w=e=>{var s=I();r(e,s)},k=e=>{var s=K();D(s,5,()=>p,G,($,i)=>{var o=J(),v=a(o),b=a(v),c=a(b),j=a(c,!0);t(c);var h=m(c,2),M=a(h);t(h),t(b),P(2),t(v),t(o),R(O=>{E(o,"href",`/category/${g(i).slug??""}`),H(v,1,`
                        relative
                        rounded-2xl
                        p-6
                        shadow-lg
                        hover:shadow-xl
                        transition-all
                        duration-300
                        ${O??""}
                        flex
                        items-center
                        justify-between
                        rtl
                    `,"svelte-nfclae"),x(j,g(i).name),x(M,`(${g(i).count??""} مطلب)`)},[_],T),r($,o)}),t(s),r(e,s)};B(y,e=>{p.length===0?e(w):e(k,!1)})}t(n),r(u,n),C()}export{te as component,ee as universal};
